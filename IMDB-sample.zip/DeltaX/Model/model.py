from datetime import datetime
# from app import db

# association table between Actors and Movies
actors_identifier = db.Table('actors_identifier',
	db.Column('actors_id', db.Integer, db.ForeignKey('actors.aid')),
	db.Column('movies_id', db.Integer, db.ForeignKey('movies.mid'))
)

class Actors(db.Model):
	__tablename__ = 'actors'
	aid = db.Column(db.Integer, primary_key = True)
	name = db.Column(db.String(100), nullable = False)
	sex = db.Column(db.String(50), nullable = False)
	dob = db.Column(db.DateTime, nullable = False, default = datetime.utcnow)
	bio = db.Column(db.String(200), nullable = False)
	movie = db.relationship("Movies", secondary = actors_identifier, backref="actor")

	def __init__(self, name, sex, dob, bio):
		self.name = name
		self.sex = sex
		self.dob = dob
		self.bio = bio

class Movies(object):
	__tablename__ = 'movies'
	mid = db.Column(db.Integer, primary_key = True)
	name = db.Column(db.String(100), nullable = False)
	year_of_release = db.Column(db.Integer, nullable = False)
	plot = db.Column(db.String(200), nullable = False)
	poster = db.Column(db.String(100), nullable = False)

	def __init__(self, name, year_of_release, plot, poster):
		self.name = name
		self.year_of_release = year_of_release
		self.plot = plot
		self.poster = poster

class Producers(object):
	__tablename__ = 'producers'
	pid = db.Column(db.Integer, primary_key = True)
	name = db.Column(db.String(100), nullable = False)
	sex = db.Column(db.String(50), nullable = False)
	dob = db.Column(db.DateTime, nullable = False, default = datetime.utcnow)
	bio = db.Column(db.String(200), nullable = False)

	def __init__(self, name, sex, dob, bio):
		self.name = name
		self.sex = sex
		self.dob = dob
		self.bio = bio
		